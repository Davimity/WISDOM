"""Logical dataset assets, members and their streaming canonical JSONL index."""

from __future__ import annotations

import copy
import hashlib
import json
import os
import re
from collections import Counter, defaultdict
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from pathlib import Path, PurePosixPath
from typing import Any
from uuid import uuid4

from lambdaforge.experiments.FrozenJsonMapping import FrozenJsonMapping
from lambdaforge.tasks.artifacts import TaskArtifact


@dataclass(frozen=True, slots=True)
class DatasetAsset:
    """Describe an asset without equating its physical path with scientific identity."""

    path: str
    kind: str = "file"
    sha256: str | None = None
    size_bytes: int | None = None
    media_type: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not str(self.path).strip():
            raise ValueError("Dataset asset paths/URIs cannot be empty.")
        if "://" not in self.path:
            relative = PurePosixPath(self.path)
            if relative.is_absolute() or not relative.parts or ".." in relative.parts:
                raise ValueError("Local dataset asset paths must be relative and contained.")
        if self.kind not in {"file", "directory", "record", "uri"}:
            raise ValueError("Dataset asset kind must be file, directory, record or uri.")
        if self.sha256 is not None:
            digest = self.sha256.removeprefix("sha256:")
            if len(digest) != 64 or any(value not in "0123456789abcdef" for value in digest):
                raise ValueError("Dataset asset sha256 must be a hexadecimal SHA-256.")
            object.__setattr__(self, "sha256", f"sha256:{digest}")
        if self.size_bytes is not None and (
            isinstance(self.size_bytes, bool) or self.size_bytes < 0
        ):
            raise ValueError("Dataset asset size_bytes must be non-negative.")
        object.__setattr__(self, "metadata", FrozenJsonMapping(self.metadata))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> DatasetAsset:
        """Restore one asset descriptor from a persisted index record."""
        unexpected = set(value) - {
            "path",
            "kind",
            "sha256",
            "size_bytes",
            "media_type",
            "metadata",
        }
        if unexpected:
            raise ValueError(f"Unexpected dataset asset keys: {sorted(unexpected)}.")
        return cls(
            path=str(value["path"]),
            kind=str(value.get("kind", "file")),
            sha256=str(value["sha256"]) if value.get("sha256") is not None else None,
            size_bytes=(int(value["size_bytes"]) if value.get("size_bytes") is not None else None),
            media_type=(str(value["media_type"]) if value.get("media_type") is not None else None),
            metadata=value.get("metadata", {}),
        )

    def identity_dict(self) -> dict[str, Any]:
        """Return path-independent scientific asset identity."""
        return {
            "kind": self.kind,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "media_type": self.media_type,
            "metadata": copy.deepcopy(self.metadata),
            **({"uri": self.path} if self.kind == "uri" and self.sha256 is None else {}),
        }

    def to_dict(self) -> dict[str, Any]:
        """Return the complete portable asset descriptor."""
        return {
            "path": self.path,
            "kind": self.kind,
            "sha256": self.sha256,
            "size_bytes": self.size_bytes,
            "media_type": self.media_type,
            "metadata": copy.deepcopy(self.metadata),
        }

    @staticmethod
    def fingerprint_path(path: str | Path) -> tuple[str, int]:
        """Return the canonical checksum and byte size for one local dataset asset.

        Files use the conventional SHA-256 of their bytes. Directories retain the
        deterministic relative-path tree hash used by task artifacts because a
        directory has no standalone byte stream.
        """
        resolved = Path(path)
        if not resolved.is_file():
            return TaskArtifact.fingerprint_path(resolved)
        digest = hashlib.sha256()
        size = 0
        with resolved.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                digest.update(chunk)
                size += len(chunk)
        return digest.hexdigest(), size


@dataclass(frozen=True, slots=True)
class DatasetMember:
    """Bind one stable member ID to partitions, targets, metadata and arbitrary assets."""

    member_id: str
    partitions: Mapping[str, Any] = field(default_factory=dict)
    targets: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    display: Mapping[str, Any] = field(default_factory=dict)
    assets: Mapping[str, DatasetAsset] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.member_id.strip() or re.search(r"[\r\n\x00]", self.member_id):
            raise ValueError("Dataset member IDs must be non-empty single-line strings.")
        normalized_assets = {
            str(name): (
                value if isinstance(value, DatasetAsset) else DatasetAsset.from_mapping(value)
            )
            for name, value in self.assets.items()
        }
        if any(not name.strip() for name in normalized_assets):
            raise ValueError("Dataset asset logical names cannot be empty.")
        object.__setattr__(self, "partitions", FrozenJsonMapping(self.partitions))
        object.__setattr__(self, "targets", FrozenJsonMapping(self.targets))
        object.__setattr__(self, "metadata", FrozenJsonMapping(self.metadata))
        object.__setattr__(self, "display", FrozenJsonMapping(self.display))
        object.__setattr__(self, "assets", normalized_assets)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> DatasetMember:
        """Parse one canonical index record."""
        unexpected = set(value) - {
            "id",
            "partitions",
            "targets",
            "metadata",
            "display",
            "assets",
        }
        if unexpected:
            raise ValueError(f"Unexpected dataset member keys: {sorted(unexpected)}.")
        assets = value.get("assets", {})
        if not isinstance(assets, Mapping):
            raise TypeError("Dataset member assets must be a mapping.")
        return cls(
            member_id=str(value["id"]),
            partitions=value.get("partitions", {}),
            targets=value.get("targets", {}),
            metadata=value.get("metadata", {}),
            display=value.get("display", {}),
            assets={str(name): DatasetAsset.from_mapping(item) for name, item in assets.items()},
        )

    def identity_dict(self) -> dict[str, Any]:
        """Return only scientifically identity-bearing member fields."""
        return {
            "id": self.member_id,
            "partitions": copy.deepcopy(self.partitions),
            "targets": copy.deepcopy(self.targets),
            "metadata": copy.deepcopy(self.metadata),
            "assets": {name: asset.identity_dict() for name, asset in sorted(self.assets.items())},
        }

    def to_dict(self) -> dict[str, Any]:
        """Return the full persisted member record."""
        return {
            "id": self.member_id,
            "partitions": copy.deepcopy(self.partitions),
            "targets": copy.deepcopy(self.targets),
            "metadata": copy.deepcopy(self.metadata),
            "display": copy.deepcopy(self.display),
            "assets": {name: asset.to_dict() for name, asset in sorted(self.assets.items())},
        }


class DatasetIndex:
    """Read, validate, summarize and compare a canonical member index without eager loading."""

    FORMAT = "jsonl"
    VERSION = 1

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path).resolve()

    @classmethod
    def write(cls, path: str | Path, members: Iterable[DatasetMember]) -> DatasetIndex:
        """Atomically persist canonical JSONL records in caller-provided stable order."""
        destination = Path(path).resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(f".{destination.name}.{os.getpid()}.{uuid4().hex}.tmp")
        seen: set[str] = set()
        try:
            with temporary.open("w", encoding="utf-8", newline="\n") as handle:
                for member in members:
                    if member.member_id in seen:
                        raise ValueError(f"Duplicate dataset member ID: {member.member_id!r}.")
                    seen.add(member.member_id)
                    handle.write(
                        json.dumps(
                            member.to_dict(),
                            ensure_ascii=False,
                            separators=(",", ":"),
                            sort_keys=True,
                        )
                        + "\n"
                    )
            os.replace(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)
        return cls(destination)

    def __iter__(self) -> Iterator[DatasetMember]:
        """Yield members one at a time and report the exact malformed line."""
        with self.path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                try:
                    value = json.loads(line)
                except json.JSONDecodeError as error:
                    raise ValueError(
                        f"Invalid DatasetIndex JSON on line {line_number}: {error.msg}."
                    ) from error
                if not isinstance(value, Mapping):
                    raise TypeError(f"DatasetIndex line {line_number} must contain an object.")
                yield DatasetMember.from_mapping(value)

    def get(self, member_id: str) -> DatasetMember:
        """Find one member by stable ID without loading the complete index."""
        for member in self:
            if member.member_id == member_id:
                return member
        raise KeyError(f"Unknown dataset member {member_id!r}.")

    def members(
        self,
        *,
        partitions: Mapping[str, Any] | None = None,
        offset: int = 0,
        limit: int = 100,
    ) -> tuple[DatasetMember, ...]:
        """Return a bounded page optionally filtered by arbitrary partition assignments."""
        if offset < 0 or limit < 1 or limit > 10_000:
            raise ValueError("Dataset member pagination requires offset>=0 and 1<=limit<=10000.")
        selected: list[DatasetMember] = []
        skipped = 0
        expected = dict(partitions or {})
        for member in self:
            if any(member.partitions.get(key) != value for key, value in expected.items()):
                continue
            if skipped < offset:
                skipped += 1
                continue
            selected.append(member)
            if len(selected) >= limit:
                break
        return tuple(selected)

    def validate(
        self,
        root: str | Path | None = None,
        *,
        target_schema: Mapping[str, Any] | None = None,
        require_checksums: bool = False,
    ) -> dict[str, Any]:
        """Validate unique IDs and, when a root is supplied, safe declared local assets."""
        dataset_root = Path(root).resolve() if root is not None else None
        seen: set[str] = set()
        errors: list[str] = []
        warnings: list[str] = []
        count = 0
        for member in self:
            count += 1
            if member.member_id in seen:
                errors.append(f"Duplicate member ID: {member.member_id}")
            seen.add(member.member_id)
            if target_schema and any(
                key in target_schema for key in ("$schema", "type", "properties", "required")
            ):
                from jsonschema import Draft202012Validator

                for error in Draft202012Validator(dict(target_schema)).iter_errors(
                    dict(member.targets)
                ):
                    errors.append(f"{member.member_id}.targets: {error.message}")
            if dataset_root is None:
                continue
            for name, asset in member.assets.items():
                if "://" in asset.path:
                    continue
                unresolved = dataset_root / asset.path
                resolved = unresolved.resolve(strict=False)
                if (
                    unresolved.is_symlink()
                    or not resolved.is_relative_to(dataset_root)
                    or not resolved.exists()
                ):
                    errors.append(f"{member.member_id}.{name}: missing or unsafe asset")
                    continue
                if resolved.is_dir() and any(item.is_symlink() for item in resolved.rglob("*")):
                    errors.append(f"{member.member_id}.{name}: directory contains a symlink")
                    continue
                if require_checksums and asset.sha256 is None:
                    errors.append(f"{member.member_id}.{name}: local asset has no checksum")
                    continue
                if asset.sha256 is not None:
                    digest, size = DatasetAsset.fingerprint_path(resolved)
                    checksum_matches = f"sha256:{digest}" == asset.sha256
                    if not checksum_matches and resolved.is_file():
                        # DatasetArtifact v2 was initially validated with the task
                        # artifact tree hash, which prefixes a file's basename.
                        # Read it for compatibility; all new descriptors use the
                        # ordinary byte checksum above.
                        legacy_digest, _ = TaskArtifact.fingerprint_path(resolved)
                        checksum_matches = f"sha256:{legacy_digest}" == asset.sha256
                        if checksum_matches:
                            warnings.append(
                                f"{member.member_id}.{name}: legacy file checksum accepted"
                            )
                    if not checksum_matches or (
                        asset.size_bytes is not None and size != asset.size_bytes
                    ):
                        errors.append(f"{member.member_id}.{name}: asset integrity differs")
        return {
            "valid": not errors,
            "member_count": count,
            "errors": errors,
            "warnings": warnings,
        }

    def summary(self) -> dict[str, Any]:
        """Derive universal counts from logical members rather than manual split fields."""
        partitions: dict[str, Counter[str]] = defaultdict(Counter)
        asset_types: Counter[str] = Counter()
        targets: dict[str, Counter[str]] = defaultdict(Counter)
        members = 0
        missing_assets = 0
        for member in self:
            members += 1
            for name, value in member.partitions.items():
                partitions[name][str(value)] += 1
            for name, value in member.targets.items():
                targets[name][json.dumps(value, sort_keys=True, default=str)] += 1
            for asset in member.assets.values():
                asset_types[asset.kind] += 1
                if asset.sha256 is None:
                    missing_assets += 1
        return {
            "member_count": members,
            "partitions": {
                name: dict(sorted(counts.items())) for name, counts in sorted(partitions.items())
            },
            "targets": {
                name: dict(sorted(counts.items())) for name, counts in sorted(targets.items())
            },
            "asset_types": dict(sorted(asset_types.items())),
            "assets_without_checksum": missing_assets,
        }

    def identity(self, global_assets: Mapping[str, Any] | None = None) -> str:
        """Hash scientific member content in a path-independent canonical stream."""
        digest = hashlib.sha256()
        digest.update(b"lambdaforge-dataset-index-v1\0")
        for member in self:
            digest.update(
                json.dumps(
                    member.identity_dict(),
                    ensure_ascii=False,
                    separators=(",", ":"),
                    sort_keys=True,
                ).encode("utf-8")
            )
            digest.update(b"\n")
        digest.update(
            json.dumps(
                dict(global_assets or {}),
                ensure_ascii=False,
                separators=(",", ":"),
                sort_keys=True,
            ).encode("utf-8")
        )
        return f"sha256:{digest.hexdigest()}"

    def file_sha256(self) -> str:
        """Return the checksum of the concrete persisted JSONL representation."""
        digest = hashlib.sha256()
        with self.path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                digest.update(chunk)
        return f"sha256:{digest.hexdigest()}"

    def diff(self, other: DatasetIndex) -> dict[str, Any]:
        """Compare member identities and classify scientific changes."""
        left = {member.member_id: member.identity_dict() for member in self}
        right = {member.member_id: member.identity_dict() for member in other}
        common = sorted(set(left) & set(right))
        changed = [member_id for member_id in common if left[member_id] != right[member_id]]
        partition_changes = [
            member_id
            for member_id in changed
            if left[member_id]["partitions"] != right[member_id]["partitions"]
        ]
        target_changes = [
            member_id
            for member_id in changed
            if left[member_id]["targets"] != right[member_id]["targets"]
        ]
        asset_changes = [
            member_id
            for member_id in changed
            if left[member_id]["assets"] != right[member_id]["assets"]
        ]
        return {
            "added": sorted(set(right) - set(left)),
            "removed": sorted(set(left) - set(right)),
            "changed": changed,
            "partition_changes": partition_changes,
            "target_changes": target_changes,
            "asset_identity_changes": asset_changes,
        }
