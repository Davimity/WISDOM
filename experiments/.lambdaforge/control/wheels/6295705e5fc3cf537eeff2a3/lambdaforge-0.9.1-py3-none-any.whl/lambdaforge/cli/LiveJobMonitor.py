"""Responsive, dependency-light interactive control-plane monitor."""

from __future__ import annotations

import multiprocessing
import os
import select
import shutil
import sys
import time
from collections import defaultdict, deque
from collections.abc import Mapping
from contextlib import AbstractContextManager
from multiprocessing.connection import Connection
from typing import Any, TextIO

from lambdaforge.cli.common import age
from lambdaforge.controlplane.JobService import JobService
from lambdaforge.controlplane.OverviewService import OverviewService


def _ram(observed: Mapping[str, Any]) -> float | None:
    total, available = observed.get("ram_total_bytes"), observed.get("ram_available_bytes")
    if not isinstance(total, (int, float)) or not total or not isinstance(available, (int, float)):
        return None
    return 100 * (1 - float(available) / float(total))


def _gpu(observed: Mapping[str, Any]) -> float | None:
    values = observed.get("gpus", ())
    if not isinstance(values, (list, tuple)):
        return None
    percentages = [
        float(item.get("utilization_percent", 0)) for item in values if isinstance(item, Mapping)
    ]
    return sum(percentages) / len(percentages) if percentages else None


def _seconds(value: object) -> str:
    if not isinstance(value, (int, float)):
        return "-"
    value = max(0, int(value))
    if value < 60:
        return f"{value}s"
    if value < 3600:
        return f"{value // 60}m{value % 60:02d}s"
    if value < 86400:
        return f"{value // 3600}h{value % 3600 // 60:02d}m"
    return f"{value // 86400}d{value % 86400 // 3600:02d}h"


def _bytes(value: object) -> str:
    if not isinstance(value, (int, float)):
        return "-"
    amount = float(value)
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if abs(amount) < 1024 or unit == "TiB":
            return f"{amount:.0f}{unit}" if unit in {"B", "KiB"} else f"{amount:.1f}{unit}"
        amount /= 1024
    return "-"


class ResourceHistory:
    """Retain a configurable in-memory window of total and personal observations."""

    def __init__(self, window_seconds: float = 60) -> None:
        if window_seconds < 1:
            raise ValueError("Resource history must cover at least one second.")
        self.window_seconds = float(window_seconds)
        self.values: dict[str, deque[tuple[float, dict[str, float | None]]]] = defaultdict(deque)

    def record(self, payload: Mapping[str, Any]) -> None:
        now = time.time()
        for cluster in payload.get("clusters", ()):
            if not isinstance(cluster, Mapping):
                continue
            name = str(cluster.get("cluster", "-"))
            observed = cluster.get("observed", {})
            observed = observed if isinstance(observed, Mapping) else {}
            personal = cluster.get("personal", {})
            personal = personal if isinstance(personal, Mapping) else {}
            mine = personal.get("observed", {})
            mine = mine if isinstance(mine, Mapping) else {}
            cpu_total, ram_total = observed.get("cpu_total"), observed.get("ram_total_bytes")
            gpu_total = (
                sum(
                    float(item.get("memory_total_bytes", 0) or 0)
                    for item in observed.get("gpus", ())
                    if isinstance(item, Mapping)
                )
                if isinstance(observed.get("gpus", ()), (list, tuple))
                else 0
            )
            has_actual = bool(mine.get("job_count"))
            sample = {
                "cpu": float(observed["cpu_load"])
                if isinstance(observed.get("cpu_load"), (int, float))
                else None,
                "ram": _ram(observed),
                "gpu": _gpu(observed),
                "my_cpu": 100 * float(mine.get("cpu_percent", 0) or 0) / float(cpu_total)
                if has_actual and isinstance(cpu_total, (int, float)) and cpu_total
                else None,
                "my_ram": 100 * float(mine.get("rss_bytes", 0) or 0) / float(ram_total)
                if has_actual and isinstance(ram_total, (int, float)) and ram_total
                else None,
                "my_gpu": 100 * float(mine.get("gpu_memory_bytes", 0) or 0) / gpu_total
                if has_actual and gpu_total
                else None,
            }
            self.values[name].append((now, sample))
            while self.values[name] and self.values[name][0][0] < now - self.window_seconds:
                self.values[name].popleft()

    def series(self, cluster: str, key: str) -> tuple[float | None, ...]:
        return tuple(sample.get(key) for _, sample in self.values.get(cluster, ()))


class MonitorRenderer:
    """Render immutable snapshots while leaving I/O and actions to the monitor."""

    _SPARK = "▁▂▃▄▅▆▇█"

    @classmethod
    def render(
        cls,
        payload: Mapping[str, Any],
        *,
        selected: int = 0,
        selected_cluster: int = 0,
        focus: str = "jobs",
        history: ResourceHistory | None = None,
        log_text: str = "",
        message: str = "",
        width: int = 120,
        height: int | None = None,
    ) -> str:
        del log_text  # compatibility with the original public renderer signature
        jobs = payload.get("jobs", {})
        jobs = jobs if isinstance(jobs, Mapping) else {}
        items = jobs.get("items", ())
        items = items if isinstance(items, list) else []
        states = jobs.get("by_state", {})
        states = states if isinstance(states, Mapping) else {}
        clusters = [item for item in payload.get("clusters", ()) if isinstance(item, Mapping)]
        terminal_height = height or shutil.get_terminal_size((width, 30)).lines
        cluster_capacity = max(1, min(len(clusters) or 1, max(2, terminal_height // 4)))
        cluster_start = max(0, min(selected_cluster, len(clusters) - 1) - cluster_capacity + 1)
        generated = str(payload.get("generated_at_utc", ""))
        lines = [
            "LambdaForge live jobs",
            (
                f"updated {generated[11:19] or '-'}  "
                f"preparing={states.get('preparing', 0)} "
                f"staging={states.get('staging', 0)} queued={states.get('queued', 0)} "
                f"running={states.get('running', 0)} failed={states.get('failed', 0)} "
                f"total={jobs.get('total', 0)}"
            ),
            "",
            (
                f"CLUSTERS (history {int(history.window_seconds) if history else 0}s; "
                "total then my LambdaForge jobs)"
            ),
        ]
        for offset, cluster in enumerate(
            clusters[cluster_start : cluster_start + cluster_capacity]
        ):
            index = cluster_start + offset
            name = str(cluster.get("cluster", "-"))
            observed = cluster.get("observed", {})
            observed = observed if isinstance(observed, Mapping) else {}
            personal = cluster.get("personal", {})
            personal = personal if isinstance(personal, Mapping) else {}
            mine = personal.get("observed", {})
            mine = mine if isinstance(mine, Mapping) else {}
            requested = personal.get("requested", {})
            requested = requested if isinstance(requested, Mapping) else {}
            marker = "▶" if focus == "clusters" and index == selected_cluster else " "
            lines.append(
                f"{marker} {name:<17.17} "
                f"{'online' if cluster.get('online') else 'offline':<7} "
                f"CPU {cls._metric(observed.get('cpu_load'), history, name, 'cpu')} "
                f"RAM {cls._metric(_ram(observed), history, name, 'ram')} "
                f"GPU {cls._metric(_gpu(observed), history, name, 'gpu')}"
            )
            cpu_total, ram_total = observed.get("cpu_total"), observed.get("ram_total_bytes")
            gpu_total = (
                sum(
                    float(item.get("memory_total_bytes", 0) or 0)
                    for item in observed.get("gpus", ())
                    if isinstance(item, Mapping)
                )
                if isinstance(observed.get("gpus", ()), (list, tuple))
                else 0
            )
            actual = bool(mine.get("job_count"))
            my_cpu = (
                100 * float(mine.get("cpu_percent", 0) or 0) / float(cpu_total)
                if actual and isinstance(cpu_total, (int, float)) and cpu_total
                else None
            )
            my_ram = (
                100 * float(mine.get("rss_bytes", 0) or 0) / float(ram_total)
                if actual and isinstance(ram_total, (int, float)) and ram_total
                else None
            )
            my_gpu = (
                100 * float(mine.get("gpu_memory_bytes", 0) or 0) / gpu_total
                if actual and gpu_total
                else None
            )
            lines.append(
                f"  {'↳ me':<17} {'actual' if actual else 'unknown':<7} "
                f"CPU {cls._metric(my_cpu, history, name, 'my_cpu')} "
                f"RAM {cls._metric(my_ram, history, name, 'my_ram')} "
                f"GPU {cls._metric(my_gpu, history, name, 'my_gpu')} "
                f"req C{requested.get('cpu_cores', 0)} "
                f"R{_bytes(requested.get('ram_bytes'))} G{requested.get('gpu_count', 0)}"
            )
        if cluster_start or cluster_start + cluster_capacity < len(clusters):
            last_cluster = min(len(clusters), cluster_start + cluster_capacity)
            lines.append(f"  clusters {cluster_start + 1}-{last_cluster} of {len(clusters)}")
        lines.extend(
            (
                "",
                "  JOB                             NAME             TYPE           "
                "STATE       CLUSTER      RUN      AGE      USED / REQUESTED",
            )
        )
        capacity = max(1, terminal_height - len(lines) - 4)
        start = max(0, min(selected, len(items) - 1) - capacity + 1)
        visible = items[start : start + capacity]
        for offset, job in enumerate(visible):
            index = start + offset
            metadata = job.get("metadata", {}) if isinstance(job, Mapping) else {}
            metadata = metadata if isinstance(metadata, Mapping) else {}
            timing = job.get("timing", {}) if isinstance(job, Mapping) else {}
            timing = timing if isinstance(timing, Mapping) else {}
            runtime = timing.get("runtime_seconds")
            runtime_text = (
                "waiting"
                if runtime is None and job.get("state") in {"preparing", "staging", "queued"}
                else _seconds(runtime if runtime is not None else timing.get("elapsed_seconds"))
            )
            marker = "▶" if focus == "jobs" and index == selected else " "
            lines.append(
                f"{marker} {str(job.get('job_id', '-')):<32.32} "
                f"{str(metadata.get('name', '-')):<16.16} "
                f"{str(job.get('job_type', '-')):<14.14} "
                f"{str(job.get('state', '-')):<11.11} "
                f"{str(job.get('cluster', '-')):<12.12} {runtime_text:<8.8} "
                f"{age(str(job.get('created_at_utc', ''))):<8} {cls._job_usage(job)}"
            )
        if visible:
            job = items[min(selected, len(items) - 1)]
            metadata = job.get("metadata", {})
            metadata = metadata if isinstance(metadata, Mapping) else {}
            lines.extend(
                (
                    "",
                    f"Selected: {job.get('job_id')}  "
                    f"scheduler={job.get('scheduler_id') or 'not acknowledged'}  "
                    f"phase={metadata.get('submission_phase', '-')}",
                )
            )
        lines.extend(
            ("", message or "Tab focus · ↑/↓ scroll · l full logs · x cancel · r refresh · q quit")
        )
        return "\n".join(line[:width] for line in lines[:terminal_height])

    @classmethod
    def _metric(cls, value: object, history: ResourceHistory | None, cluster: str, key: str) -> str:
        current = float(value) if isinstance(value, (int, float)) else None
        series = history.series(cluster, key) if history else ()
        return (
            f"{current:3.0f}% {cls._spark(series):<10}"
            if current is not None
            else f"  ?% {cls._spark(series):<10}"
        )

    @classmethod
    def _spark(cls, values: tuple[float | None, ...], width: int = 10) -> str:
        selected = values[-width:]
        if not selected or all(value is None for value in selected):
            return "·"
        return "".join(
            "·" if value is None else cls._SPARK[min(7, max(0, round(float(value) * 7 / 100)))]
            for value in selected
        )

    @staticmethod
    def _job_usage(job: Mapping[str, Any]) -> str:
        usage = job.get("usage", {})
        usage = usage if isinstance(usage, Mapping) else {}
        observed = usage.get("observed", {})
        observed = observed if isinstance(observed, Mapping) else {}
        requested = usage.get("requested", job.get("resources", {}))
        requested = requested if isinstance(requested, Mapping) else {}
        actual = (
            f"C{float(observed.get('cpu_percent', 0) or 0) / 100:.1f} "
            f"R{_bytes(observed.get('rss_bytes'))} "
            f"V{_bytes(observed.get('gpu_memory_bytes'))}"
            if observed
            else "actual ?"
        )
        return (
            f"{actual} / req C{requested.get('cpu_cores', 0)} "
            f"R{_bytes(requested.get('ram_bytes'))} G{requested.get('gpu_count', 0)}"
        )


class LogViewerRenderer:
    """Render a complete, scrollable log document."""

    @staticmethod
    def render(
        job_id: str, text: str, *, scroll: int, message: str, width: int, height: int
    ) -> str:
        lines = text.splitlines()
        capacity = max(1, height - 4)
        start = min(max(0, len(lines) - capacity), max(0, scroll))
        end = min(len(lines), start + capacity)
        header = (
            f"LambdaForge log · {job_id} · lines {start + 1 if lines else 0}-{end} of {len(lines)}"
        )
        return "\n".join(
            [
                header[:width],
                "",
                *(line[:width] for line in lines[start:end]),
                "",
                (message or "↑/↓ line · PgUp/PgDn page · Home/End · b/Esc/q back")[:width],
            ]
        )


class _TerminalSession(AbstractContextManager["_TerminalSession"]):
    """Restore terminal flags and screen even when interrupted."""

    def __init__(self, stream: TextIO = sys.stdout) -> None:
        self.stream = stream
        self.fd = sys.stdin.fileno()
        self.previous: list[Any] | None = None
        self.termios: Any = None

    def __enter__(self) -> _TerminalSession:
        import termios
        import tty

        self.termios, self.previous = termios, termios.tcgetattr(self.fd)
        tty.setcbreak(self.fd)
        self.stream.write("\x1b[?1049h\x1b[?25l")
        self.stream.flush()
        return self

    def __exit__(self, *exc: object) -> None:
        if self.previous is not None:
            self.termios.tcsetattr(self.fd, self.termios.TCSADRAIN, self.previous)
        self.stream.write("\x1b[?25h\x1b[?1049l")
        self.stream.flush()

    def key(self, timeout: float) -> str | None:
        if not select.select([self.fd], [], [], timeout)[0]:
            return None
        value = os.read(self.fd, 8).decode(errors="ignore")
        if value == "\x1b":
            deadline = time.monotonic() + 0.03
            while len(value) < 8 and time.monotonic() < deadline:
                ready = select.select([self.fd], [], [], max(0, deadline - time.monotonic()))[0]
                if not ready:
                    break
                value += os.read(self.fd, 8 - len(value)).decode(errors="ignore")
        return value


def _collect_snapshot(overview: OverviewService, connection: Connection) -> None:
    try:
        connection.send((overview.snapshot(), None))
    except BaseException as error:
        connection.send((None, f"{error.__class__.__name__}: {error}"))
    finally:
        connection.close()


def _collect_logs(jobs: JobService, job_id: str, connection: Connection) -> None:
    try:
        connection.send((jobs.logs(job_id), None))
    except BaseException as error:
        connection.send((None, f"{error.__class__.__name__}: {error}"))
    finally:
        connection.close()


class BackgroundProcess:
    """Run one cancellable provider call outside the interactive process."""

    def __init__(self, target: Any, arguments: tuple[Any, ...], name: str) -> None:
        self.target, self.arguments, self.name = target, arguments, name
        self.process: Any = None
        self.connection: Connection | None = None

    @property
    def running(self) -> bool:
        return self.process is not None and self.process.is_alive()

    def start(self) -> None:
        if self.running:
            return
        self.close()
        parent, child = multiprocessing.get_context("fork").Pipe(duplex=False)
        self.process = multiprocessing.get_context("fork").Process(
            target=self.target, args=(*self.arguments, child), daemon=True, name=self.name
        )
        self.process.start()
        child.close()
        self.connection = parent

    def take(self) -> tuple[Any | None, str | None] | None:
        if self.connection is None or not self.connection.poll():
            return None
        try:
            result = self.connection.recv()
        except EOFError:
            result = (None, "Background worker exited without returning data.")
        self._release()
        return result

    def close(self) -> None:
        if self.process is not None and self.process.is_alive():
            self.process.terminate()
            self.process.join(timeout=0.2)
            if self.process.is_alive() and hasattr(self.process, "kill"):
                self.process.kill()
                self.process.join(timeout=0.2)
        self._release()

    def _release(self) -> None:
        if self.connection is not None:
            self.connection.close()
        if self.process is not None:
            self.process.join(timeout=0.1)
            if self.process.is_alive():
                self.process.terminate()
                self.process.join(timeout=0.1)
            self.process.close()
        self.connection = self.process = None


class SnapshotProcess(BackgroundProcess):
    """Collect a global snapshot without blocking terminal input."""

    def __init__(self, overview: OverviewService) -> None:
        super().__init__(_collect_snapshot, (overview,), "lambdaforge-top-snapshot")


class LogProcess(BackgroundProcess):
    """Load a complete remote log without blocking terminal input."""

    def __init__(self, jobs: JobService, job_id: str) -> None:
        super().__init__(_collect_logs, (jobs, job_id), "lambdaforge-top-logs")


class LiveJobMonitor:
    """Coordinate background observations and explicit interactive actions."""

    def __init__(
        self,
        overview: OverviewService,
        jobs: JobService,
        *,
        interval: float = 2,
        history_seconds: float = 60,
        stream: TextIO = sys.stdout,
    ) -> None:
        if interval < 0.2:
            raise ValueError("Live monitor interval must be at least 0.2 seconds.")
        self.overview, self.jobs, self.interval = overview, jobs, interval
        self.history_seconds, self.stream = history_seconds, stream

    def run(self) -> int:
        selected = selected_cluster = log_scroll = 0
        focus, mode, log_job, log_text, message = "jobs", "jobs", "", "", ""
        payload: Mapping[str, Any] = {}
        history, dirty = ResourceHistory(self.history_seconds), True
        poller, log_poller = SnapshotProcess(self.overview), None
        poller.start()
        next_refresh = time.monotonic() + self.interval
        try:
            with _TerminalSession(self.stream) as terminal:
                while True:
                    completed = poller.take()
                    if completed:
                        updated, error = completed
                        if isinstance(updated, Mapping):
                            payload = updated
                            history.record(payload)
                            if mode == "jobs":
                                message = ""
                        elif mode == "jobs":
                            message = f"Refresh failed: {error}"
                        next_refresh, dirty = time.monotonic() + self.interval, True
                    if log_poller is not None and (loaded := log_poller.take()):
                        value, error = loaded
                        log_text = str(value or "")
                        log_scroll = max(
                            0,
                            len(log_text.splitlines())
                            - max(1, shutil.get_terminal_size((120, 30)).lines - 4),
                        )
                        message, log_poller, dirty = (
                            (f"Log load failed: {error}" if error else ""),
                            None,
                            True,
                        )
                    if time.monotonic() >= next_refresh and not poller.running:
                        poller.start()
                        next_refresh = time.monotonic() + self.interval
                    items = payload.get("jobs", {}).get("items", [])
                    clusters = payload.get("clusters", [])
                    selected = min(selected, max(0, len(items) - 1))
                    selected_cluster = min(selected_cluster, max(0, len(clusters) - 1))
                    size = shutil.get_terminal_size((120, 30))
                    if dirty:
                        rendered = (
                            LogViewerRenderer.render(
                                log_job,
                                log_text,
                                scroll=log_scroll,
                                message=message or ("Loading complete log…" if log_poller else ""),
                                width=size.columns,
                                height=size.lines,
                            )
                            if mode == "logs"
                            else MonitorRenderer.render(
                                payload,
                                selected=selected,
                                selected_cluster=selected_cluster,
                                focus=focus,
                                history=history,
                                message=message or ("Loading providers…" if not payload else ""),
                                width=size.columns,
                                height=size.lines,
                            )
                        )
                        self.stream.write("\x1b[H\x1b[2J" + rendered)
                        self.stream.flush()
                        dirty = False
                    key = terminal.key(0.05)
                    if mode == "logs":
                        page, maximum = (
                            max(1, size.lines - 5),
                            max(0, len(log_text.splitlines()) - max(1, size.lines - 4)),
                        )
                        if key in {"q", "Q", "b", "B", "\x1b"}:
                            if log_poller:
                                log_poller.close()
                                log_poller = None
                            mode, message, dirty = "jobs", "", True
                        elif key in {"j", "\x1b[B"}:
                            log_scroll, dirty = min(maximum, log_scroll + 1), True
                        elif key in {"k", "\x1b[A"}:
                            log_scroll, dirty = max(0, log_scroll - 1), True
                        elif key == "\x1b[6~":
                            log_scroll, dirty = min(maximum, log_scroll + page), True
                        elif key == "\x1b[5~":
                            log_scroll, dirty = max(0, log_scroll - page), True
                        elif key in {"g", "\x1b[H", "\x1b[1~"}:
                            log_scroll, dirty = 0, True
                        elif key in {"G", "\x1b[F", "\x1b[4~"}:
                            log_scroll, dirty = maximum, True
                        continue
                    if key in {"q", "Q"}:
                        return 0
                    if key == "\t":
                        focus, dirty = ("clusters" if focus == "jobs" else "jobs"), True
                    elif key in {"j", "\x1b[B"}:
                        if focus == "clusters":
                            selected_cluster = min(max(0, len(clusters) - 1), selected_cluster + 1)
                        else:
                            selected = min(max(0, len(items) - 1), selected + 1)
                        dirty = True
                    elif key in {"k", "\x1b[A"}:
                        if focus == "clusters":
                            selected_cluster = max(0, selected_cluster - 1)
                        else:
                            selected = max(0, selected - 1)
                        dirty = True
                    elif key == "r":
                        if not poller.running:
                            poller.start()
                        message, dirty = "Refreshing providers in the background…", True
                    elif key == "l" and items:
                        log_job, log_text, log_scroll, message, mode = (
                            str(items[selected]["job_id"]),
                            "",
                            0,
                            "",
                            "logs",
                        )
                        log_poller = LogProcess(self.jobs, log_job)
                        log_poller.start()
                        dirty = True
                    elif key == "x" and items:
                        job_id = str(items[selected]["job_id"])
                        message = f"Press y to cancel {job_id}; any other key aborts."
                        dirty = True
                        if terminal.key(10) == "y":
                            record = self.jobs.cancel(job_id)
                            message = f"{record.job_id}: {record.state.value}"
                            if not poller.running:
                                poller.start()
                        else:
                            message = "Cancellation aborted."
        finally:
            poller.close()
            if log_poller is not None:
                log_poller.close()
