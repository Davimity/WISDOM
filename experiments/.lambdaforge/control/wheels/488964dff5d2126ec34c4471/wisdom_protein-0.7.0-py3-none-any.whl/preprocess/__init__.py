"""WISDOM structural preprocessing."""

__version__ = "0.7.0"

__all__ = ["__version__"]
