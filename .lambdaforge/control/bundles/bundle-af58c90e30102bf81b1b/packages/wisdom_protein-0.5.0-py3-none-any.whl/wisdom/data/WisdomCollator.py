"""Disjoint-graph batching for variable-size WISDOM proteins."""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import torch
from torch import Tensor


class WisdomCollator:
    """Concatenate proteins and offset all three sparse graph domains deterministically."""

    def __call__(self, samples: Sequence[Mapping[str, Tensor]]) -> Mapping[str, Tensor]:
        """Build one disconnected tensor graph batch from ordered protein samples.

        Preprocessing stores an undirected atomic or surface pair once with ``src<dst``. LambdaForge
        graph encoders consume directed ``source -> destination`` edges, so each stored pair is
        expanded to both orientations here. Bipartite edges retain their semantic orientation
        ``surface -> atom`` because WISDOMv1 gathers atom embeddings explicitly by its two rows.

        Args:
            samples: Non-empty ordered sequence returned by ``WisdomDataset``. Protein ``b`` becomes
                batch index ``b`` without random reordering inside this operation.

        Returns:
            Mapping of concatenated features, bidirectional atom/surface graph edges, offset
            surface-to-atom incidence, ``atom_batch[N]``, ``surface_batch[M]`` and ``target[B]``.

        Raises:
            ValueError: If ``samples`` is empty or any offset endpoint leaves its concatenated node
                domain, indicating an inconsistent dataset/collator contract.
        """
        if not samples:
            raise ValueError("cannot collate an empty protein batch")

        atomic_numbers: list[Tensor]          = []
        residue_type_ids: list[Tensor]        = []
        atom_edges: list[Tensor]              = []
        atom_edge_types: list[Tensor]         = []
        atom_batches: list[Tensor]            = []
        surface_curvatures: list[Tensor]      = []
        surface_edges: list[Tensor]           = []
        bipartite_edges: list[Tensor]         = []
        surface_weights: list[Tensor]         = []
        surface_batches: list[Tensor]         = []
        targets: list[Tensor]                 = []

        atom_offset    = 0
        surface_offset = 0
        for batch_index, sample in enumerate(samples):
            atom_count    = len(sample["atomic_numbers"])
            surface_count = len(sample["surface_area_weights"])

            atomic_numbers.append(sample["atomic_numbers"])
            residue_type_ids.append(sample["residue_type_ids"])
            atom_batches.append(
                torch.full((atom_count,), batch_index, dtype=torch.long)
            )

            stored_atom_edges = sample["atom_edge_index"] + atom_offset
            atom_edges.extend((stored_atom_edges, stored_atom_edges.flip(0)))
            atom_edge_types.extend((sample["atom_edge_types"], sample["atom_edge_types"]))

            surface_curvatures.append(sample["surface_curvatures"])
            surface_weights.append(sample["surface_area_weights"])
            surface_batches.append(
                torch.full((surface_count,), batch_index, dtype=torch.long)
            )

            stored_surface_edges = sample["surface_edge_index"] + surface_offset
            surface_edges.extend((stored_surface_edges, stored_surface_edges.flip(0)))

            bipartite_offset = torch.tensor(
                [[surface_offset], [atom_offset]],
                dtype=torch.long,
            )
            bipartite_edges.append(sample["surface_atom_edge_index"] + bipartite_offset)
            targets.append(sample["target"])

            atom_offset    += atom_count
            surface_offset += surface_count

        batch = {
            "atomic_numbers": torch.cat(atomic_numbers),
            "residue_type_ids": torch.cat(residue_type_ids),
            "atom_edge_index": torch.cat(atom_edges, dim=1),
            "atom_edge_types": torch.cat(atom_edge_types),
            "atom_batch": torch.cat(atom_batches),
            "surface_curvatures": torch.cat(surface_curvatures),
            "surface_edge_index": torch.cat(surface_edges, dim=1),
            "surface_atom_edge_index": torch.cat(bipartite_edges, dim=1),
            "surface_area_weights": torch.cat(surface_weights),
            "surface_batch": torch.cat(surface_batches),
            "target": torch.stack(targets),
        }

        # Assertions remain active because an invalid offset would silently mix proteins.
        if batch["atom_edge_index"].numel() and (
            batch["atom_edge_index"].min() < 0
            or batch["atom_edge_index"].max() >= atom_offset
        ):
            raise ValueError("batched atom edge index is out of range")
        if batch["surface_edge_index"].numel() and (
            batch["surface_edge_index"].min() < 0
            or batch["surface_edge_index"].max() >= surface_offset
        ):
            raise ValueError("batched surface edge index is out of range")

        bipartite = batch["surface_atom_edge_index"]
        if bipartite.numel() and (
            bipartite[0].min() < 0
            or bipartite[0].max() >= surface_offset
            or bipartite[1].min() < 0
            or bipartite[1].max() >= atom_offset
        ):
            raise ValueError("batched surface-to-atom edge index is out of range")
        return batch
