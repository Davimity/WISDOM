"""Minimal pickle-free ingestion of labeled WISDOM NPZ representations."""

from __future__ import annotations

import csv
from collections.abc import Mapping
from pathlib import Path

import numpy as np
import torch
from torch import Tensor
from torch.utils.data import Dataset


class WisdomDataset(Dataset[Mapping[str, Tensor]]):
    """Load one explicit labeled split without changing preprocessed geometry."""

    COLUMNS = ("file", "label", "split")
    SPLITS  = frozenset({"train", "val", "test"})

    def __init__(
        self,
        manifest: str | Path,
        split   : str,
    ) -> None:
        """Read and validate a compact ``file,label,split`` CSV manifest.

        Paths are resolved relative to the manifest directory. Rows keep CSV order and only rows
        whose explicit split equals ``split`` are retained; no random or implicit division occurs.
        NPZ files remain unopened until ``__getitem__`` so DataLoader workers do not share handles.

        Args:
            manifest: CSV path with exactly the columns ``file,label,split``. ``file`` addresses a
                WISDOM NPZ, ``label`` is binary 0/1, and ``split`` is train/val/test.
            split: Explicit subset to expose; one of ``train``, ``val``, or ``test``.

        Raises:
            ValueError: If the split, header, label, row split, path, or selected subset is invalid.
            OSError: If the manifest cannot be read.
        """
        if split not in self.SPLITS:
            raise ValueError(f"split must be one of {sorted(self.SPLITS)}")

        manifest_path = Path(manifest).resolve()
        records: list[tuple[Path, int]] = []
        with manifest_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if tuple(reader.fieldnames or ()) != self.COLUMNS:
                raise ValueError(f"manifest columns must be exactly {self.COLUMNS}")

            for line_number, row in enumerate(reader, start=2):
                row_split = str(row["split"]).strip()
                if row_split not in self.SPLITS:
                    raise ValueError(f"manifest line {line_number} has invalid split {row_split!r}")
                try:
                    label = int(str(row["label"]).strip())
                except ValueError as error:
                    raise ValueError(
                        f"manifest line {line_number} label must be integer 0 or 1"
                    ) from error
                if label not in {0, 1}:
                    raise ValueError(f"manifest line {line_number} label must be 0 or 1")

                file_value = str(row["file"]).strip()
                if not file_value:
                    raise ValueError(f"manifest line {line_number} file cannot be empty")
                path = Path(file_value)
                if not path.is_absolute():
                    path = manifest_path.parent / path
                path = path.resolve()
                if not path.is_file() or path.suffix.lower() != ".npz":
                    raise ValueError(f"manifest line {line_number} does not reference an NPZ file")
                if row_split == split:
                    records.append((path, label))

        if not records:
            raise ValueError(f"manifest contains no records for split {split!r}")

        self.manifest = manifest_path
        self.split    = split
        self.records  = tuple(records)

    def __len__(self) -> int:
        """Return the number of explicitly labeled proteins in the selected split.

        Returns:
            Count of retained manifest records.
        """
        return len(self.records)

    def __getitem__(self, index: int) -> Mapping[str, Tensor]:
        """Load only WISDOMv1 arrays and convert them to correctly typed tensors.

        Relation bit masks use preprocessing meanings ``1=spatial``, ``2=covalent`` and
        ``3=both``. WISDOMv1 maps them deterministically to R-GCN relation IDs ``0,1,2`` by
        subtracting one. Atom/surface graphs remain in their stored undirected-once ``src<dst``
        form here; ``WisdomCollator`` creates both directed message-passing orientations.

        Args:
            index: Zero-based selected-split record index.

        Returns:
            Mapping containing integer atom categories/edges/relations, float32 curvature and area
            tensors, the surface-to-atom incidence, and one scalar float32 binary target.

        Raises:
            IndexError: If ``index`` is outside the selected split.
            ValueError: If required arrays, shapes, finite values, relation semantics, or endpoint
                ranges are inconsistent with the current WISDOM NPZ contract.
            OSError: If the NPZ cannot be opened.
        """
        path, label = self.records[index]
        required = {
            "atomic_numbers",
            "residue_type_ids",
            "atom_edge_index",
            "atom_edge_relation_mask",
            "surface_curvatures",
            "surface_edge_index",
            "surface_atom_edge_index",
            "surface_area_weights",
        }
        with np.load(path, allow_pickle=False) as archive:
            missing = required - set(archive.files)
            if missing:
                raise ValueError(f"{path.name} is missing WISDOMv1 arrays: {sorted(missing)}")
            values = {name: archive[name] for name in required}

        atom_count    = len(values["atomic_numbers"])
        surface_count = len(values["surface_area_weights"])

        # Categories and continuous point features establish model input dimensions.
        if values["atomic_numbers"].shape != (atom_count,) or atom_count == 0:
            raise ValueError("atomic_numbers must have non-empty shape [N]")
        if values["residue_type_ids"].shape != (atom_count,):
            raise ValueError("residue_type_ids must have shape [N]")
        if np.any(values["atomic_numbers"] <= 0):
            raise ValueError("atomic_numbers must contain positive element identifiers")

        curvatures = values["surface_curvatures"]
        weights    = values["surface_area_weights"]
        if curvatures.ndim != 3 or curvatures.shape[0] != surface_count or curvatures.shape[2] != 3:
            raise ValueError("surface_curvatures must have shape [M,S,3]")
        if surface_count == 0 or weights.shape != (surface_count,):
            raise ValueError("surface_area_weights must have non-empty shape [M]")
        if (
            not np.isfinite(curvatures).all()
            or not np.isfinite(weights).all()
            or np.any(weights <= 0)
        ):
            raise ValueError(
                "surface curvature and area tensors must be finite with positive weights"
            )

        # Sparse topology remains compact; every endpoint is checked before tensor construction.
        atom_edges    = values["atom_edge_index"]
        surface_edges = values["surface_edge_index"]
        bipartite     = values["surface_atom_edge_index"]
        relation_mask = values["atom_edge_relation_mask"]
        for name, edge_index in (
            ("atom_edge_index", atom_edges),
            ("surface_edge_index", surface_edges),
            ("surface_atom_edge_index", bipartite),
        ):
            if edge_index.ndim != 2 or edge_index.shape[0] != 2:
                raise ValueError(f"{name} must have shape [2,E]")
            if edge_index.dtype.kind not in "iu":
                raise ValueError(f"{name} must use an integer dtype")
        if relation_mask.shape != (atom_edges.shape[1],) or not np.all(
            np.isin(relation_mask, (1, 2, 3))
        ):
            raise ValueError("atom relation masks must use preprocessing values 1, 2, or 3")
        if atom_edges.size and (
            atom_edges.min() < 0
            or atom_edges.max() >= atom_count
            or not np.all(atom_edges[0] < atom_edges[1])
        ):
            raise ValueError("atom_edge_index endpoints/order are invalid")
        if surface_edges.size and (
            surface_edges.min() < 0
            or surface_edges.max() >= surface_count
            or not np.all(surface_edges[0] < surface_edges[1])
        ):
            raise ValueError("surface_edge_index endpoints/order are invalid")
        if bipartite.size and (
            bipartite[0].min() < 0
            or bipartite[0].max() >= surface_count
            or bipartite[1].min() < 0
            or bipartite[1].max() >= atom_count
        ):
            raise ValueError("surface_atom_edge_index endpoints are invalid")

        return {
            "atomic_numbers": torch.from_numpy(values["atomic_numbers"].astype(np.int64)),
            "residue_type_ids": torch.from_numpy(values["residue_type_ids"].astype(np.int64)),
            "atom_edge_index": torch.from_numpy(atom_edges.astype(np.int64)),
            "atom_edge_types": torch.from_numpy(relation_mask.astype(np.int64) - 1),
            "surface_curvatures": torch.from_numpy(curvatures.astype(np.float32)),
            "surface_edge_index": torch.from_numpy(surface_edges.astype(np.int64)),
            "surface_atom_edge_index": torch.from_numpy(bipartite.astype(np.int64)),
            "surface_area_weights": torch.from_numpy(weights.astype(np.float32)),
            "target": torch.tensor(float(label), dtype=torch.float32),
        }
