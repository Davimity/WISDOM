"""WISDOM v2 controlled multiple-instance pooling experiment."""

from __future__ import annotations

from typing import Any, ClassVar

import torch
from lambdaforge.nn import Scatter
from lambdaforge.nn.pooling import (
    FractionalTopKMeanPooling,
    GatedAttentionPooling,
    LogSumExpPooling,
    SparseMaxPooling,
    SparseMeanPooling,
)
from torch import Tensor, nn

from wisdom.models.PoolingType import PoolingType
from wisdom.models.WisdomV1 import WisdomV1


class WisdomV2(WisdomV1):
    """Keep the v1 backbone fixed while comparing protein-level MIL rules."""

    output_schema: ClassVar[dict[str, Any]] = {
        "logits": "Tensor[B]",
        "surface_logits": "Tensor[M]",
        "surface_probabilities": "Tensor[M]",
        "localization_scores": "Tensor[M]",
        "positive_area_fraction": "Tensor[B]",
        "localization_entropy": "Tensor[B]",
        "maximum_surface_probability": "Tensor[B]",
        "attention_weights": "Tensor[M], present only for attention pooling",
    }

    def __init__(
        self,
        hidden_dim             : int = 128,
        embedding_dim          : int = 32,
        use_residue_type       : bool = True,
        atomic_layers          : int = 2,
        projection_depth       : int = 1,
        surface_layers         : int = 2,
        dropout                : float = 0.2,
        pooling_type           : PoolingType | str = PoolingType.MAX,
        topk_fraction          : float = 0.05,
        attention_hidden_dim   : int = 32,
        regional_levels       : int = 1,
        log_sum_exp_beta       : float = 5.0,
        atomic_number_count    : int = 119,
        residue_type_count     : int = 21,
        curvature_features     : int = 6,
    ) -> None:
        """Build a fixed v1 backbone and exactly one configured pooling hypothesis.

        MAX and arithmetic mean use LambdaForge's sparse indexed poolers. Fractional top-k and
        normalized log-sum-exp use its dense masked poolers. Global attention uses LambdaForge's
        gated attention network to score the learned surface representations, then applies those
        weights to the separate local positivity logits. Consequently, an attention coefficient is
        an importance weight for protein classification, not a claim that the point is positive.
        ``local_mean_max`` is WISDOM's domain-specific operation: it repeatedly computes an
        area-weighted mean over each surface vertex and its graph neighbors, then applies sparse
        global MAX.

        Args:
            hidden_dim: Fixed latent width selected by the v1 protocol.
            embedding_dim: Fixed categorical embedding width selected by v1.
            use_residue_type: Fixed v1 choice of element-only or element-plus-residue features.
            atomic_layers: Fixed number of v1 relational graph convolutions.
            projection_depth: Fixed number of v1 curvature/chemistry projection layers.
            surface_layers: Fixed number of v1 surface graph convolutions.
            dropout: Shared dropout, allowed only a small v2 retuning range.
            pooling_type: One value from :class:`PoolingType` selecting the v2 hypothesis.
            topk_fraction: Fraction of valid points averaged by ``topk``; independent of protein
                point count and valid only in ``(0,1]``.
            attention_hidden_dim: Internal LambdaForge gated-attention width.
            regional_levels: Number of successive one-hop area-weighted consensus steps for
                ``local_mean_max``. Values one, two, and three are the intended v2 range.
            log_sum_exp_beta: Positive inverse temperature of normalized log-sum-exp.
            atomic_number_count: Number of atomic-number embedding rows.
            residue_type_count: Number of residue-category embedding rows.
            curvature_features: Flattened preprocessing curvature width.

        Raises:
            ValueError: If the pooling name or one of its numerical parameters is invalid, or if
                the inherited v1 architecture parameters are invalid.
        """
        super().__init__(
            hidden_dim=hidden_dim,
            embedding_dim=embedding_dim,
            use_residue_type=use_residue_type,
            atomic_layers=atomic_layers,
            projection_depth=projection_depth,
            surface_layers=surface_layers,
            dropout=dropout,
            atomic_number_count=atomic_number_count,
            residue_type_count=residue_type_count,
            curvature_features=curvature_features,
        )

        try:
            selected_pooling = PoolingType(pooling_type)
        except ValueError as error:
            valid = ", ".join(value.value for value in PoolingType)
            raise ValueError(f"pooling_type must be one of: {valid}") from error
        if not 0.0 < topk_fraction <= 1.0:
            raise ValueError("topk_fraction must be in (0,1]")
        if attention_hidden_dim < 1:
            raise ValueError("attention_hidden_dim must be positive")
        if regional_levels < 1:
            raise ValueError("regional_levels must be positive")
        if log_sum_exp_beta <= 0.0:
            raise ValueError("log_sum_exp_beta must be positive")

        self.pooling_type        = selected_pooling
        self.regional_levels     = regional_levels
        self.sparse_max_pooling  = SparseMaxPooling()
        self.sparse_mean_pooling = SparseMeanPooling()

        self.dense_pooling     : nn.Module | None = None
        self.attention_pooling : GatedAttentionPooling | None = None
        if selected_pooling is PoolingType.TOPK:
            self.dense_pooling = FractionalTopKMeanPooling(
                fraction=topk_fraction,
                min_k=1,
            )
        elif selected_pooling is PoolingType.LOG_SUM_EXP:
            self.dense_pooling = LogSumExpPooling(beta=log_sum_exp_beta, normalize=True)
        elif selected_pooling is PoolingType.ATTENTION:
            self.attention_pooling = GatedAttentionPooling(
                in_features=hidden_dim,
                hidden_features=attention_hidden_dim,
            )

    def pool_surface_logits(
        self,
        surface_logits       : Tensor,
        surface_embeddings   : Tensor,
        surface_edge_index   : Tensor,
        surface_area_weights : Tensor,
        surface_batch        : Tensor,
    ) -> dict[str, Tensor]:
        """Aggregate point logits according to the configured v2 scientific hypothesis.

        For regional consensus, one step maps the current point logit ``l_i`` to
        ``r_j = (w_j*l_j + sum_{i->j} w_i*l_i) / (w_j + sum_{i->j} w_i)``, where ``w_i`` is the
        represented surface area and ``i->j`` is a directed surface edge. Repeating the expression
        expands the receptive region by one graph hop per level. The final protein logit is the
        maximum regional value. No coordinates, dense distance matrix, or new neighborhood are
        constructed.

        Global attention first computes normalized weights ``alpha_i`` from surface embeddings via
        LambdaForge gated attention, then returns ``sum_i alpha_i*l_i``. Thus the value being
        averaged remains the positivity logit while the representation decides importance.

        Args:
            surface_logits: Local positivity evidence with shape ``[M]``.
            surface_embeddings: Learned surface representations with shape ``[M,hidden_dim]``.
            surface_edge_index: Bidirectional surface graph with shape ``[2,Es]``.
            surface_area_weights: Positive represented-area values with shape ``[M]``.
            surface_batch: Ordered consecutive protein ownership IDs with shape ``[M]``.

        Returns:
            Mapping containing protein ``logits[B]``. Attention pooling additionally returns
            ``attention_weights[M]`` in original sparse point order.

        Raises:
            ValueError: If tensor shapes, graph endpoints, graph isolation, or produced pooling
                values violate the v2 contract.
        """
        surface_count = len(surface_logits)
        if surface_logits.ndim != 1:
            raise ValueError("surface_logits must have shape [M]")
        if surface_embeddings.shape != (surface_count, self.hidden_dim):
            raise ValueError("surface_embeddings must have shape [M,hidden_dim]")
        if (
            surface_area_weights.shape != (surface_count,)
            or surface_batch.shape != (surface_count,)
        ):
            raise ValueError("surface weights and batch IDs must have shape [M]")
        if surface_edge_index.ndim != 2 or surface_edge_index.shape[0] != 2:
            raise ValueError("surface_edge_index must have shape [2,Es]")

        protein_count = int(surface_batch.max().item()) + 1
        if surface_edge_index.numel():
            source_ids = surface_edge_index[0]
            target_ids = surface_edge_index[1]
            if source_ids.min() < 0 or surface_edge_index.max() >= surface_count:
                raise ValueError("surface graph endpoints are out of range")
            if not torch.equal(surface_batch[source_ids], surface_batch[target_ids]):
                raise ValueError("surface graph edges must not cross protein boundaries")

        if self.pooling_type is PoolingType.MAX:
            logits = self.sparse_max_pooling(
                surface_logits.unsqueeze(-1), surface_batch, protein_count
            ).squeeze(-1)
            return {"logits": logits}
        if self.pooling_type is PoolingType.MEAN:
            logits = self.sparse_mean_pooling(
                surface_logits.unsqueeze(-1), surface_batch, protein_count
            ).squeeze(-1)
            return {"logits": logits}

        if self.pooling_type is PoolingType.LOCAL_MEAN_MAX:
            regional_logits = surface_logits
            source_ids      = surface_edge_index[0]
            target_ids      = surface_edge_index[1]
            for _ in range(self.regional_levels):
                weighted_values = surface_area_weights * regional_logits
                numerator       = weighted_values + Scatter.sum(
                    weighted_values[source_ids], target_ids, surface_count
                )
                denominator = surface_area_weights + Scatter.sum(
                    surface_area_weights[source_ids], target_ids, surface_count
                )
                regional_logits = numerator / denominator

            logits = self.sparse_max_pooling(
                regional_logits.unsqueeze(-1), surface_batch, protein_count
            ).squeeze(-1)
            return {"logits": logits}

        # LambdaForge dense poolers receive only compact bags; graph tensors remain sparse.
        counts        = torch.bincount(surface_batch, minlength=protein_count)
        starts        = torch.cumsum(counts, dim=0) - counts
        local_ids     = torch.arange(surface_count, device=surface_batch.device)
        local_ids    -= starts[surface_batch]
        maximum_size = int(counts.max().item())

        dense_logits = surface_logits.new_zeros((protein_count, maximum_size, 1))
        dense_features = surface_embeddings.new_zeros(
            (protein_count, maximum_size, self.hidden_dim)
        )
        valid_mask = torch.zeros(
            (protein_count, maximum_size),
            dtype=torch.bool,
            device=surface_logits.device,
        )
        dense_logits[surface_batch, local_ids, 0]  = surface_logits
        dense_features[surface_batch, local_ids]   = surface_embeddings
        valid_mask[surface_batch, local_ids]       = True

        if self.pooling_type is PoolingType.ATTENTION:
            if self.attention_pooling is None:
                raise ValueError("attention pooling was not constructed")
            dense_weights = self.attention_pooling.attention_weights(dense_features, valid_mask)
            logits        = (dense_weights * dense_logits.squeeze(-1)).sum(dim=1)
            return {
                "logits": logits,
                "attention_weights": dense_weights[surface_batch, local_ids],
            }

        if self.dense_pooling is None:
            raise ValueError("dense pooling was not constructed")
        pooled = self.dense_pooling(dense_logits, valid_mask)
        if not isinstance(pooled, Tensor) or pooled.shape != (protein_count, 1):
            raise ValueError("LambdaForge dense pooling must return shape [B,1]")
        return {"logits": pooled.squeeze(-1)}

    def forward(
        self,
        atomic_numbers          : Tensor,
        residue_type_ids        : Tensor,
        atom_edge_index         : Tensor,
        atom_edge_types         : Tensor,
        surface_curvatures      : Tensor,
        surface_edge_index      : Tensor,
        surface_atom_edge_index : Tensor,
        surface_area_weights    : Tensor,
        surface_batch           : Tensor,
    ) -> dict[str, Tensor]:
        """Predict with one pooling rule and expose label-free localization diagnostics.

        The inherited encoder produces surface representations and local logits. Only the selected
        protein pooling changes. Local sigmoid probabilities remain in exact NPZ point order.
        ``localization_scores`` normalize ``area * exp(local_logit)`` within each protein; their
        entropy is zero for a concentrated map and approaches one for a uniform map.
        ``positive_area_fraction`` measures represented area with local probability at least 0.5.
        These quantities diagnose map behavior but are not localization accuracy metrics because
        the current label manifests contain no point-level ground truth.

        Args:
            atomic_numbers: Integer atomic numbers with shape ``[N]``.
            residue_type_ids: Integer residue categories with shape ``[N]``.
            atom_edge_index: Bidirectional atomic edges with shape ``[2,Ea]``.
            atom_edge_types: R-GCN relation IDs with shape ``[Ea]``.
            surface_curvatures: Multiscale ``(H,K,C)`` values with shape ``[M,S,3]``.
            surface_edge_index: Bidirectional surface edges with shape ``[2,Es]``.
            surface_atom_edge_index: ``[surface,atom]`` incidence with shape ``[2,Esa]``.
            surface_area_weights: Positive represented-area values with shape ``[M]``.
            surface_batch: Ordered protein owner for every point with shape ``[M]``.

        Returns:
            Protein logits, local logits/probabilities/scores, and per-protein localization
            diagnostics. Attention runs also contain the distinct attention weights.

        Raises:
            ValueError: If the inherited graph contract or the configured pooling contract fails,
                or if any protein-level pooling output is non-finite.
        """
        # Validate the shared bag contract once before the expensive graph encoders run.
        protein_count = self.validate_surface_bags(
            surface_area_weights,
            surface_batch,
            len(surface_curvatures),
        )
        surface_embeddings, surface_logits = self.encode_surface(
            atomic_numbers=atomic_numbers,
            residue_type_ids=residue_type_ids,
            atom_edge_index=atom_edge_index,
            atom_edge_types=atom_edge_types,
            surface_curvatures=surface_curvatures,
            surface_edge_index=surface_edge_index,
            surface_atom_edge_index=surface_atom_edge_index,
        )
        pooling = self.pool_surface_logits(
            surface_logits=surface_logits,
            surface_embeddings=surface_embeddings,
            surface_edge_index=surface_edge_index,
            surface_area_weights=surface_area_weights,
            surface_batch=surface_batch,
        )
        if not torch.isfinite(pooling["logits"]).all():
            raise ValueError("MIL pooling returned a non-finite protein logit")

        surface_count = len(surface_logits)

        # Area-aware normalized local scores make maps comparable across sampling densities.
        epsilon           = torch.finfo(surface_logits.dtype).eps
        area_sum          = Scatter.sum(surface_area_weights, surface_batch, protein_count)
        normalized_area   = surface_area_weights / area_sum[surface_batch].clamp_min(epsilon)
        localization_seed = surface_logits + normalized_area.clamp_min(epsilon).log()
        localization      = Scatter.segment_softmax(
            localization_seed, surface_batch, protein_count
        )

        surface_probabilities = torch.sigmoid(surface_logits)
        positive_area_fraction = Scatter.sum(
            normalized_area * (surface_probabilities >= 0.5).to(surface_logits.dtype),
            surface_batch,
            protein_count,
        )
        maximum_probability = Scatter.maximum(
            surface_probabilities, surface_batch, protein_count
        )

        # Normalizing by log(point count) gives a size-independent zero-to-one concentration scale.
        entropy = -Scatter.sum(
            localization * localization.clamp_min(epsilon).log(),
            surface_batch,
            protein_count,
        )
        counts = Scatter.sum(
            surface_logits.new_ones(surface_count), surface_batch, protein_count
        )
        entropy_scale = counts.log().clamp_min(epsilon)
        entropy       = torch.where(
            counts > 1.0,
            entropy / entropy_scale,
            torch.zeros_like(entropy),
        )

        outputs = {
            "logits": pooling["logits"],
            "surface_logits": surface_logits,
            "surface_probabilities": surface_probabilities,
            "localization_scores": localization,
            "positive_area_fraction": positive_area_fraction,
            "localization_entropy": entropy,
            "maximum_surface_probability": maximum_probability,
        }
        if "attention_weights" in pooling:
            outputs["attention_weights"] = pooling["attention_weights"]
        return outputs
