"""Generic checkpoint-aware evaluation at controlled training terminal states."""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Mapping
from pathlib import Path
from typing import Any
from uuid import uuid4

from lambdaforge.experiments.ObjectFactory import ObjectFactory
from lambdaforge.experiments.RunResult import RunResult
from lambdaforge.experiments.TerminalEvaluationContext import TerminalEvaluationContext


class TerminalEvaluationService:
    """Invoke a project evaluator once a valid checkpoint becomes scientifically final."""

    REPORT_NAME = "terminal-evaluation.json"

    def evaluate(
        self,
        config        : Mapping[str, Any],
        result        : RunResult,
        terminal_state: str,
    ) -> dict[str, Any] | None:
        """Evaluate best-then-last checkpoint and persist a factual availability report.

        ``terminal_evaluation.evaluator`` is a normal public object specification. Its constructed
        object must implement ``evaluate(context)`` and return a JSON-compatible mapping. The
        framework knows nothing about the model domain, metrics, or visualization formats.

        Args:
            config: Materialized experiment configuration.
            result: Canonical training result containing checkpoint candidates.
            terminal_state: Controlled scientific terminal state such as ``completed``,
                ``early_stopped``, ``pruned``, or ``gracefully_stopped``.

        Returns:
            Persisted report mapping, or ``None`` when terminal evaluation is not configured.

        Raises:
            TypeError: If configuration or evaluator output violates the public contract.
        """
        raw = config.get("terminal_evaluation")
        if raw is None:
            return None
        if not isinstance(raw, Mapping):
            raise TypeError("terminal_evaluation must be a mapping")
        if raw.get("enabled", True) is False:
            return None
        evaluator_spec = raw.get("evaluator")
        if not isinstance(evaluator_spec, Mapping):
            raise TypeError("terminal_evaluation.evaluator must be an object specification")

        run_dir = Path(result.run_dir).resolve()
        candidates = (
            ("best", result.best_model_path),
            ("last", result.last_model_path),
        )
        selected_name: str | None = None
        checkpoint: Path | None  = None
        for name, candidate in candidates:
            if not candidate:
                continue
            candidate_path = Path(candidate)
            if not candidate_path.is_absolute():
                candidate_path = run_dir / candidate_path
            if candidate_path.is_file():
                selected_name = name
                checkpoint    = candidate_path.resolve()
                break
        if checkpoint is None:
            report: dict[str, Any] = {
                "status": "unavailable",
                "reason": "no complete best or last checkpoint exists",
                "terminal_state": terminal_state,
            }
            self._write(run_dir / self.REPORT_NAME, report)
            return report

        digest      = self._sha256(checkpoint)
        report_path = run_dir / self.REPORT_NAME
        existing    = self._matching_report(report_path, terminal_state, digest)
        if existing is not None:
            return existing

        context = TerminalEvaluationContext(
            config=config,
            run_dir=run_dir,
            checkpoint_path=checkpoint,
            checkpoint_sha256=digest,
            terminal_state=terminal_state,
        )
        try:
            evaluator = ObjectFactory.build(evaluator_spec)
            method    = getattr(evaluator, "evaluate", None)
            if not callable(method):
                raise TypeError("terminal evaluator must expose evaluate(context)")
            output = method(context)
            if not isinstance(output, Mapping):
                raise TypeError("terminal evaluator must return a mapping")
            report = {
                "status": "ok",
                "terminal_state": terminal_state,
                "checkpoint_policy": "best_then_last",
                "checkpoint_role": selected_name or "unknown",
                "checkpoint_path": str(checkpoint),
                "checkpoint_sha256": digest,
                "result": dict(output),
            }
        except Exception as error:
            report = {
                "status": "unavailable",
                "terminal_state": terminal_state,
                "checkpoint_policy": "best_then_last",
                "checkpoint_role": selected_name or "unknown",
                "checkpoint_path": str(checkpoint),
                "checkpoint_sha256": digest,
                "reason": f"{type(error).__name__}: {error}",
            }
            if bool(raw.get("fail_on_error", False)):
                self._write(run_dir / self.REPORT_NAME, report)
                raise
        self._write(run_dir / self.REPORT_NAME, report)
        return report

    @staticmethod
    def _matching_report(
        path          : Path,
        terminal_state: str,
        checkpoint_sha: str,
    ) -> dict[str, Any] | None:
        """Return an already completed evaluation of the same terminal checkpoint.

        This durable idempotency guard matters when an adaptive study is resumed after the
        controller persisted its terminal decision but before the outer process returned. A
        malformed or unrelated report is ignored and replaced by a fresh evaluation.

        Args:
            path: Expected terminal report path inside the run directory.
            terminal_state: Controlled state requested by the caller.
            checkpoint_sha: SHA-256 digest of the selected checkpoint.

        Returns:
            Existing report when both terminal state and checkpoint digest match, otherwise
            ``None``.
        """
        if not path.is_file():
            return None
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(payload, dict):
            return None
        if payload.get("terminal_state") != terminal_state:
            return None
        if payload.get("checkpoint_sha256") != checkpoint_sha:
            return None
        return payload

    @staticmethod
    def _sha256(path: Path) -> str:
        """Hash a checkpoint only after it has a stable filesystem name.

        Args:
            path: Existing checkpoint file.

        Returns:
            Lowercase SHA-256 hexadecimal digest.
        """
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        return digest.hexdigest()

    @staticmethod
    def _write(path: Path, payload: Mapping[str, Any]) -> None:
        """Atomically persist a terminal evaluation availability/result envelope.

        Args:
            path: Final JSON report path.
            payload: JSON-compatible report mapping.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{os.getpid()}.{uuid4().hex}.tmp")
        try:
            with temporary.open("w", encoding="utf-8") as stream:
                json.dump(payload, stream, indent=2, sort_keys=True, allow_nan=False)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
