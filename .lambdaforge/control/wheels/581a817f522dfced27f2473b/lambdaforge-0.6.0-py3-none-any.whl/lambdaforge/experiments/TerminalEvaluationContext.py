"""Immutable context supplied to a configured terminal evaluator."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True, slots=True)
class TerminalEvaluationContext:
    """Describe one controlled terminal run and its selected checkpoint."""

    config          : Mapping[str, Any]
    run_dir         : Path
    checkpoint_path : Path
    checkpoint_sha256: str
    terminal_state  : str
