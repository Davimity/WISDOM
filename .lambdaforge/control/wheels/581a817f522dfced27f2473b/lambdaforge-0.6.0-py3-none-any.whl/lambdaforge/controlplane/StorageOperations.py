"""Bounded remote-side storage inspection and reference-aware cache deletion."""

from __future__ import annotations

import json
import shutil
import sys
import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from lambdaforge.runtime.CrossProcessFileLock import CrossProcessFileLock


class StorageOperations:
    """Operate only below exact configured internal roots."""

    @classmethod
    def status(cls, descriptor: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
        roots = cls._roots(descriptor)
        return {name: cls._usage(path) for name, path in roots.items()}

    @classmethod
    def gc(
        cls,
        descriptor: Mapping[str, Any],
        references: Mapping[str, Sequence[str]],
        *,
        apply: bool = False,
    ) -> dict[str, Any]:
        """Serialize cache collection against another collector on the same cluster."""
        cache_root = Path(str(descriptor["cache_root"])).expanduser().resolve()
        cache_root.mkdir(parents=True, exist_ok=True)
        with CrossProcessFileLock(
            cache_root / ".gc.lock",
            shared=False,
            timeout_seconds=30.0,
            poll_interval_seconds=0.1,
        ):
            return cls._gc(descriptor, references, apply=apply)

    @classmethod
    def _gc(
        cls,
        descriptor: Mapping[str, Any],
        references: Mapping[str, Sequence[str]],
        *,
        apply: bool = False,
    ) -> dict[str, Any]:
        roots = cls._roots(descriptor)
        cache_root = Path(str(descriptor["cache_root"])).expanduser().resolve()
        markers = tuple(cache_root.glob(".environment-build-*.lock"))
        if markers:
            return {
                "candidates": [],
                "reclaimable_bytes": 0,
                "applied": False,
                "blocked_reason": "A managed environment build is currently mutating cache.",
            }
        candidates: list[dict[str, Any]] = []
        candidate_paths: set[str] = set()
        now = time.time()
        maximum_age = descriptor.get("cache_max_age")
        for category, reference_key in (("bundles", "bundles"), ("environments", "environments")):
            root = roots[category]
            protected = set(str(item) for item in references.get(reference_key, ()))
            if not root.is_dir() or root.is_symlink():
                continue
            for child in sorted(root.iterdir()):
                if child.is_symlink() or not child.is_dir() or child.name in protected:
                    continue
                incomplete = ".tmp-" in child.name or not cls._complete(category, child)
                stale = maximum_age is not None and now - child.stat().st_mtime >= float(
                    maximum_age
                )
                if incomplete or stale:
                    usage = cls._usage(child)
                    item = {
                        "category": category,
                        "name": child.name,
                        "path": str(child),
                        "bytes": usage["bytes"],
                        "files": usage["files"],
                        "reason": "incomplete" if incomplete else "stale",
                    }
                    candidates.append(item)
                    candidate_paths.add(str(child.resolve()))
        temporary = roots["temporary"]
        if temporary.is_dir() and not temporary.is_symlink():
            for child in sorted(temporary.iterdir()):
                if child.is_symlink():
                    continue
                usage = cls._usage(child)
                candidates.append(
                    {
                        "category": "temporary",
                        "name": child.name,
                        "path": str(child),
                        "bytes": usage["bytes"],
                        "files": usage["files"],
                        "reason": "temporary",
                    }
                )
                candidate_paths.add(str(child.resolve()))
        maximum_size = descriptor.get("cache_max_size")
        if maximum_size is not None:
            cache_roots = (
                roots["bundles"],
                roots["environments"],
                roots["package_cache"],
                roots["temporary"],
            )
            cache_bytes = sum(int(cls._usage(path)["bytes"]) for path in cache_roots)
            reclaimable = sum(int(item["bytes"]) for item in candidates)
            quota_candidates: list[tuple[float, str, Path]] = []
            for category, reference_key in (
                ("bundles", "bundles"),
                ("environments", "environments"),
            ):
                protected = set(str(item) for item in references.get(reference_key, ()))
                root = roots[category]
                if not root.is_dir() or root.is_symlink():
                    continue
                for child in root.iterdir():
                    resolved = str(child.resolve())
                    if (
                        child.is_dir()
                        and not child.is_symlink()
                        and child.name not in protected
                        and resolved not in candidate_paths
                    ):
                        quota_candidates.append((child.stat().st_mtime, category, child))
            for _, category, child in sorted(quota_candidates):
                if cache_bytes - reclaimable <= int(maximum_size):
                    break
                usage = cls._usage(child)
                candidates.append(
                    {
                        "category": category,
                        "name": child.name,
                        "path": str(child),
                        "bytes": usage["bytes"],
                        "files": usage["files"],
                        "reason": "cache-quota",
                    }
                )
                reclaimable += int(usage["bytes"])
        if apply:
            allowed = tuple(path.resolve() for path in roots.values())
            for item in candidates:
                path = Path(str(item["path"])).resolve()
                if not any(path != root and path.is_relative_to(root) for root in allowed):
                    raise RuntimeError(f"GC target escaped configured internal roots: {path}")
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink(missing_ok=True)
        return {
            "candidates": candidates,
            "reclaimable_bytes": sum(int(item["bytes"]) for item in candidates),
            "applied": apply,
            "blocked_reason": None,
        }

    @staticmethod
    def _roots(value: Mapping[str, Any]) -> dict[str, Path]:
        state = Path(str(value["state_root"])).expanduser().resolve()
        cache = Path(str(value["cache_root"])).expanduser().resolve()
        run = Path(str(value["run_root"])).expanduser().resolve()
        dataset = value.get("dataset_root")
        return {
            "state": state,
            "bundles": cache / "bundles",
            "environments": cache / "environments",
            "package_cache": cache / "pip",
            "job_workspaces": run,
            "temporary": cache / "tmp",
            "datasets": Path(str(dataset)).expanduser().resolve()
            if dataset
            else state / "no-dataset-root",
        }

    @staticmethod
    def _usage(path: Path) -> dict[str, Any]:
        if not path.exists() or path.is_symlink():
            return {"path": str(path), "bytes": 0, "files": 0, "exists": False}
        if path.is_file():
            return {"path": str(path), "bytes": path.stat().st_size, "files": 1, "exists": True}
        files = tuple(item for item in path.rglob("*") if item.is_file() and not item.is_symlink())
        return {
            "path": str(path),
            "bytes": sum(item.stat().st_size for item in files),
            "files": len(files),
            "exists": True,
        }

    @staticmethod
    def _complete(category: str, path: Path) -> bool:
        marker = "manifest.json" if category == "bundles" else ".lambdaforge-environment.json"
        return (path / marker).is_file()

    @classmethod
    def main(cls, argv: Sequence[str] | None = None) -> int:
        values = tuple(argv if argv is not None else sys.argv[1:])
        if len(values) not in {2, 4}:
            raise SystemExit(
                "Usage: StorageOperations status DESCRIPTOR | gc DESCRIPTOR REFS APPLY"
            )
        descriptor = json.loads(values[1])
        if values[0] == "status":
            payload = cls.status(descriptor)
        elif values[0] == "gc" and len(values) == 4:
            payload = cls.gc(descriptor, json.loads(values[2]), apply=values[3] == "true")
        else:
            raise SystemExit("Unknown storage operation.")
        print(json.dumps(payload, sort_keys=True))
        return 0


if __name__ == "__main__":
    raise SystemExit(StorageOperations.main())
